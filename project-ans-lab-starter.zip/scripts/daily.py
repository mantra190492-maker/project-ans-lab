import json
from pathlib import Path
from anslab.retrieval import discover
from anslab.report import write_report

def main():
    config = json.loads(Path("config/research.json").read_text(encoding="utf-8"))
    records = discover(config["queries"], config["max_results_per_query"],
                       config["timeout_seconds"])
    records = records[:config["max_total_records"]]
    json_path, md_path = write_report(records, config["queries"])
    print(f"Retrieved {len(records)} unique records. Reports: {json_path}, {md_path}")

if __name__ == "__main__":
    main()
