# Project ANS Lab
Cloud-first, reproducible biomedical literature discovery for ANS-003 (adult-onset neuromuscular disease differentiation).

## First run
Python 3.11+:
```bash
python -m pip install -r requirements.txt
python -m scripts.daily
python -m pytest -q
```
Results are written to `reports/` as JSON and Markdown. Only public metadata/abstracts are retrieved; no paywall bypass or patient records.

## GitHub setup
1. Create a **private** repository named `project-ans-lab` in your GitHub account.
2. Upload the contents of this archive to the repository root.
3. Enable Actions in repository settings and run **ANS Literature Scout** manually.
4. The scheduled workflow runs daily at 09:00 UTC; outputs are uploaded as workflow artifacts.

## Research scope
ANS-001: autonomic regulation (later).
ANS-003: differentiating inclusion body myositis, muscular dystrophies and motor neuron disease.
No clinical diagnosis or prediction claims. Evidence from abstracts is flagged as such.

## Cost
Default implementation uses free public APIs and no paid LLM. Monitor GitHub Actions free-tier allowance and API rate limits.
